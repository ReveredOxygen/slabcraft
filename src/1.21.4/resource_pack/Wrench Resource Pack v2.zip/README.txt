This pack adds custom textures for GoldenDelicios's rotator wrench datapack.

datapack github: https://github.com/GoldenDelicios/block_rotator
